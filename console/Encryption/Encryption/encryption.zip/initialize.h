#ifndef __initialize_h__
#define __initialize_h__
	
	void checker(char*str);
	char str[50];
	char str_star[50];
	int temp = 0;
	const char star = '*';
	int numeric_con = 0;
	const int secret = 2984;

#endif